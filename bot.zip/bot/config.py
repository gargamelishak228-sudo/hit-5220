"""Конфигурация бота."""

import os
from typing import Optional


class Settings:
    """Настройки бота."""
    
    def __init__(self):
        self.bot_token = "5113818184:AAH7DfuEyasWsgeu5mWXf5FvrJl22ymYKCE"
        self.admin_id = 1908213720
        if self.admin_id:
            try:
                self.admin_id = int(self.admin_id)
            except ValueError:
                self.admin_id = None
        
        self.max_message_length = 4096
        self.history_limit = 50
        self.database_url = "sqlite:///./slang_bot.db"


# Глобальный экземпляр настроек
settings = Settings()