"""Voxys Slang Bot - Телеграм бот для перевода сленга."""

__version__ = "1.0.0"
__author__ = "Voxys Team"
