"""Точка входа для Voxys Slang Bot."""

from bot import main
import asyncio

if __name__ == "__main__":
    asyncio.run(main())